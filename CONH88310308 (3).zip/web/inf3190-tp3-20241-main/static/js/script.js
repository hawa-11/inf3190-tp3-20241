function validateForm(event) {
    event.preventDefault();

    const form = document.getElementById('adoptionForm');
    const errorContainer = document.getElementById('errorMessages');
    errorContainer.innerHTML = '';

    let isValid = true;

    const nom = form.nom.value.trim();
    const espece = form.espece.value.trim();
    const race = form.race.value.trim();
    const age = parseInt(form.age.value);
    const description = form.description.value.trim();
    const courriel = form.courriel.value.trim();
    const adresse = form.adresse.value.trim();
    const ville = form.ville.value.trim();
    const cp = form.cp.value.trim();

    if (!nom || !espece || !race || !age || !description || !courriel || !adresse || !ville || !cp) {
        displayError('Tous les champs sont obligatoires.');
        isValid = false;
    }

    if (nom.length < 3 || nom.length > 20) {
        displayError('Le nom de l\'animal doit avoir entre 3 et 20 caractères.');
        isValid = false;
    }

    if (isNaN(age) || age < 0 || age > 30) {
        displayError('L\'âge doit être un nombre entre 0 et 30.');
        isValid = false;
    }

    if (courriel && !isValidEmail(courriel)) {
        displayError('Adresse courriel invalide.');
        isValid = false;
    }

    if (/[,\s]/.test(nom) || /[,\s]/.test(espece) || /[,\s]/.test(race) || /[,\s]/.test(description)) {
        displayError('Aucun champ ne peut contenir une virgule.');
        isValid = false;
    }

    const postalCodeRegex = /^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$/;
    if (!cp.match(postalCodeRegex)) {
        displayError('Format du code postal invalide (format canadien).');
        isValid = false;
    }

    if (isValid) {
        // Soumettre le formulaire si toutes les validations sont passées
        form.submit();
    }

    function displayError(message) {
        const errorMessage = document.createElement('div');
        errorMessage.textContent = message;
        errorMessage.className = 'error';
        errorContainer.appendChild(errorMessage);
    }

    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
}