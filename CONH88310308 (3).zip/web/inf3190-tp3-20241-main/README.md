# inf3190-tp3-20241

Conde Hadja Hawa (CONH88310308)

# installez les dépendances Python requises à l'aide de pip :
pip install -r requirements.txt
# Lancez l'application Flask en exécutant la commande suivante dans le répertoire racine de votre application :
flask run