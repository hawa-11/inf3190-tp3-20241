from flask import Flask
from .database import Database

def create_app():
    app = Flask(__name__, static_url_path="", static_folder="static")

    # Configuration de l'application Flask (routes, configuration, etc.)
    # Exemple : Importer les routes depuis index.py
    from . import index

    # Initialisation de la base de données
    with app.app_context():
        db = Database()

    return app