# Copyright 2024 <Conde Hadja Hawa (CONH88310308)>
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import random
from flask import Flask
from flask import render_template
from flask import request 
from flask import redirect
from flask import url_for
from flask import flash
from flask import g
from .database import Database

app = Flask(__name__, static_url_path="", static_folder="static")

# Instance de la classe Database
db = Database()

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        g._database = Database()
    return g._database


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.disconnect()


# Page d'accueil affichant 5 animaux au hasard
@app.route('/')
def index():
    db = get_db()
    animals = db.get_animaux()
    
    db.disconnect()
    return render_template('index.html', animals=animals)

# Page de détails d'un animal spécifique
@app.route('/animal/<int:animal_id>')
def animal_details(animal_id):
    db = get_db()
    animal = db.get_animal(animal_id)
    if animal is None:
        flash("Animal non trouvé.", "error")  # Message d'erreur
        return redirect(url_for('index'))  # Redirection vers la page d'accueil
    return render_template('animal_details.html', animal=animal)
    
# Page de recherche d'animaux
@app.route('/search', methods=['GET'])
def search():
    return render_template('search.html')

# Résultats de la recherche d'animaux
@app.route('/search_results', methods=['POST'])
def search_results():
    
    query = request.form['query']
    db = get_db()
    all_animals = db.get_animaux()

    if query:
        results = [animal for animal in all_animals if query.lower() in animal['nom'].lower()]
    else:
        # Si la requête est vide, retourne tous les animaux
        results = all_animals

    return render_template('search_results.html', results=results)

# Formulaire pour mettre un animal en adoption
@app.route('/adoption_form', methods=['GET', 'POST'])
def adoption_form():
    if request.method == 'POST':
        nom = request.form['nom']
        espece = request.form['espece']
        race = request.form['race']
        age = request.form['age']
        description = request.form['description']
        courriel = request.form['courriel']
        adresse = request.form['adresse']
        ville = request.form['ville']
        cp = request.form['cp']

        # Valider les données du formulaire
        if not validate_form(request.form):
            flash("Veuillez remplir tous les champs correctement.", "error")
            return redirect(url_for('form'))

        # Enregistrer l'animal dans la base de données
        db = get_db()
        animal_id = db.add_animal(nom, espece, race, age, description, courriel, adresse, ville, cp)
        flash("L'animal a été ajouté avec succès!", "success")
        return redirect(url_for('animal_details', animal_id=animal_id))
    else:
        animal = {
            
            "espece": "Chien",
            "race": "Labrador",
            "age": 5,
            "description": "Un chien joueur et affectueux.",
            "courriel": "example@example.com",
            "adresse": "123 rue Principale",
            "ville": "Montreal",
            "cp": "H1A1A1"
        }
        return render_template('adoption_form.html', animal=animal)
    

# Fonction pour valider les données du formulaire
def validate_form(form_data):
    nom = form_data['nom']
    espece = form_data['espece']
    race = form_data['race']
    age = form_data['age']
    description = form_data['description']
    courriel = form_data['courriel']
    adresse = form_data['adresse']
    ville = form_data['ville']
    cp = form_data['cp']

    
    if not (nom and espece and race and age and description and courriel and adresse and ville and cp):
        flash("Tous les champs sont obligatoires.", "error")
        return False

    if len(nom) < 3 or len(nom) > 20:
        flash("Le nom de l'animal doit avoir entre 3 et 20 caractères.", "error")
        return False

    try:
        age = int(age)
        if age < 0 or age > 30:
            flash("L'âge doit être un nombre entre 0 et 30.", "error")
            return False
    except ValueError:
        flash("L'âge doit être un nombre valide.", "error")
        return False

    if not is_valid_email(courriel):
        flash("Adresse courriel invalide.", "error")
        return False

    if not is_valid_postal_code(cp):
        flash("Format du code postal invalide (format canadien).", "error")
        return False

    return True

def is_valid_email(email):
    # Utiliser une expression régulière pour valider l'adresse courriel
    email_pattern = r'^[^\s@]+@[^\s@]+\.[^\s@]+$'
    return bool(re.match(email_pattern, email))

def is_valid_postal_code(postal_code):
    # Utiliser une expression régulière pour valider le code postal canadien
    postal_code_pattern = r'^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$'
    return bool(re.match(postal_code_pattern, postal_code))

@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

if __name__ == '__main__':
    app.run(debug=True)